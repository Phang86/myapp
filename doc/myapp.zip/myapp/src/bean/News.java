package bean;

public class News {
	private String newsTitle;
	private String authorName;
	private String headerUrl;
	private int commentCount;
	private String releaseDate;
	private int type;
	private String picx;
	private String picxx;
	private String picxxx;
	public String getNewsTitle() {
		return newsTitle;
	}
	public String getAuthorName() {
		return authorName;
	}
	public String getHeaderUrl() {
		return headerUrl;
	}
	public int getCommentCount() {
		return commentCount;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public int getType() {
		return type;
	}
	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public void setHeaderUrl(String headerUrl) {
		this.headerUrl = headerUrl;
	}
	public void setCommentCount(int commentCount) {
		this.commentCount = commentCount;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getPicx() {
		return picx;
	}
	public String getPicxx() {
		return picxx;
	}
	public String getPicxxx() {
		return picxxx;
	}
	public void setPicx(String picx) {
		this.picx = picx;
	}
	public void setPicxx(String picxx) {
		this.picxx = picxx;
	}
	public void setPicxxx(String picxxx) {
		this.picxxx = picxxx;
	}
	@Override
	public String toString() {
		return "News [newsTitle=" + newsTitle + ", authorName=" + authorName + ", headerUrl=" + headerUrl
				+ ", commentCount=" + commentCount + ", releaseDate=" + releaseDate + ", type=" + type + ", picx="
				+ picx + ", picxx=" + picxx + ", picxxx=" + picxxx + "]";
	}
	
}
