package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import bean.My;
import bean.News;
import bean.User;
import bean.VideoList;
import util.DBConnection;

public class UserDAO {
	//tb_user����¼
	public List<User> findAll(String user, String pwd){
		List<User> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from tb_user where username=? and password=?";
//		if(!"".equals(user)){
//			  sql += "and username = "+user;
//		}
//		if(!"".equals(mobile)){
//			  sql += "and password= "+mobile;
//		}
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			pst.setString(1, user);
			pst.setString(2, pwd);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				User u = new User();
				u.setUserId(rst.getInt("user_id"));
				u.setUserName(rst.getString("username"));
				u.setMobile(rst.getString("mobile"));
				u.setPassWord(rst.getString("password"));
				u.setCreateTime(rst.getString("create_time"));
				list.add(u);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	//tb_user��ע��
	public int add(User user) {
		int num = 0;
		Connection con = DBConnection.getCon();
		String sql = "insert into tb_user values(null,?,?,?,?)";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, user.getUserName());
			pst.setString(2, user.getMobile());
			pst.setString(3, user.getPassWord());
			pst.setString(4, user.getCreateTime());
			num = pst.executeUpdate();
			DBConnection.close(con, pst, null);
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
		return num;
	}
	//video_list��
	public List<VideoList> findVideoAll() {
		List<VideoList> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from video_list";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				VideoList vl = new VideoList();
				vl.setvId(rst.getInt("vid"));
				vl.setTitle(rst.getString("vtitle"));
				vl.setAuthor(rst.getString("author"));
				vl.setCoverUrl(rst.getString("coverUrl"));
				vl.setHeadurl(rst.getString("headurl"));
				vl.setCommentNum(rst.getInt("comment_num"));
				vl.setLikeNum(rst.getInt("like_num"));
				vl.setCollectNum(rst.getInt("collect_num"));
				vl.setPlayUrl(rst.getString("playUrl"));
				list.add(vl);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public List<News> findNews() {
		List<News> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from news";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				News ne = new News();
				ne.setNewsTitle(rst.getString("news_title"));
				ne.setAuthorName(rst.getString("author_name"));
				ne.setHeaderUrl(rst.getString("header_url"));
				ne.setCommentCount(rst.getInt("comment_count"));
				ne.setReleaseDate(rst.getString("release_date"));
				ne.setPicx(rst.getString("picx"));
				ne.setPicxx(rst.getString("picxx"));
				ne.setPicxxx(rst.getString("picxxx"));
				ne.setType(rst.getInt("type"));
				list.add(ne);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	
	public List<My> findMy() {
		List<My> list = new ArrayList<>();
		Connection connection = DBConnection.getCon();
		String sql = "select * from my";
		try {
			PreparedStatement pst = connection.prepareStatement(sql);
			ResultSet rst = pst.executeQuery();
			while(rst.next()) {
				My me = new My();
				me.setTitleImg(rst.getString("title_img"));
				me.setTitleName(rst.getString("title_name"));
				me.setTitleAuthor(rst.getString("title_author"));
				me.setReadCount(rst.getInt("read_count"));
				me.setLikeCount(rst.getInt("like_count"));
				me.setCommentCount(rst.getInt("comment_count"));
				me.setEnjoyCount(rst.getInt("enjoy_count"));
				list.add(me);
			}
			DBConnection.close(connection, pst, rst);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
}
